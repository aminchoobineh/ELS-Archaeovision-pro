export interface LicenseData {
  systemId: string;
  licenseKey: string;
  activatedAt: number;
  expiresAt: number;
}